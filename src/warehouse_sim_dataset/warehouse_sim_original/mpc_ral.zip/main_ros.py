#!/usr/bit/env python3

import rospy
import message_filters

from geometry_msgs.msg import PoseStamped
from geometry_msgs.msg import PoseWithCovarianceStamped
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from nav_msgs.srv import GetPlan

from tf import transformations

class UnicyclePose:

    def __init__(self, x = 0.0, y = 0.0, theta = 0.0, time_stamp = rospy.Time(0), frame_id = 'map'):
        self.x = x
        self.y = y
        self.theta = theta
        self.time_stamp = time_stamp
        self.frame_id = frame_id

    def __str__(self) -> str:
        result = f"x: {self.x:0.3f}, y:{self.y:0.3f}, theta :{self.theta:0.3f}, TimeStamp: {self.time_stamp}, FrameID: {self.frame_id} "
        return result

    def toPoseStamped(self) -> PoseStamped:
        result = PoseStamped()

        result.header.seq = 0
        result.header.stamp = self.time_stamp
        result.header.frame_id = self.frame_id

        result.pose.position.x = self.x
        result.pose.position.y = self.y
        result.pose.position.z = 0

        quaternion = transformations.quaternion_from_euler(0.0, 0.0, self.theta)
        result.pose.orientation.x = quaternion[0]
        result.pose.orientation.y = quaternion[1]
        result.pose.orientation.z = quaternion[2]
        result.pose.orientation.w = quaternion[3]

        return result


def toUnicyclePose(pose_stamped: PoseStamped) -> UnicyclePose:
    x = pose_stamped.pose.position.x
    y = pose_stamped.pose.position.y
    quaternion = (  pose_stamped.pose.orientation.x,
                    pose_stamped.pose.orientation.y,
                    pose_stamped.pose.orientation.z,
                    pose_stamped.pose.orientation.w
                )
    eulerRPY = transformations.euler_from_quaternion(quaternion)
    theta = eulerRPY[-1]
    result = UnicyclePose(x = x, y = y, theta = theta, time_stamp = pose_stamped.header.stamp, frame_id = pose_stamped.header.frame_id)
    return result


def cleanUp():
  print("shutdown time!")


def getGlobalPlan(start: PoseStamped, end: PoseStamped)->list:
    rospy.wait_for_service('/global_path_planner/make_plan')
    try:
        planner_server = rospy.ServiceProxy('/global_path_planner/make_plan', GetPlan)
        plan = planner_server(start, end, 0.1)
        return plan.plan
    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)


def getPlan(start: UnicyclePose, end: UnicyclePose)->list:
    if start.frame_id != end.frame_id:
        return []
    start_pose = start.toPoseStamped()
    end_pose = end.toPoseStamped()
    
    plan = getGlobalPlan(start_pose, end_pose)
    result = [toUnicyclePose(waypoint) for waypoint in plan.poses]

    return result


def setRobotVelocity(vx: float, vy: float, omega: float, duration: rospy.rostime.Duration, frequency: float):
    
    velocity_command = Twist()
    
    velocity_command.linear.x = vx
    velocity_command.linear.y = vy
    velocity_command.linear.z = 0

    velocity_command.angular.x = 0
    velocity_command.angular.y = 0
    velocity_command.angular.z = omega

    velocity_publisher = rospy.Publisher('/mobile_base_controller/cmd_vel', Twist, queue_size = 1)
    rate = rospy.Rate(frequency)

    start_time = rospy.get_rostime()
    while (rospy.get_rostime() - start_time)<duration:
        velocity_publisher.publish(velocity_command)
        rate.sleep()


def getRobotPose(estimated = False, timeout = 1) -> UnicyclePose:
    if estimated:
        robot_pose = rospy.wait_for_message('/amcl_pose', PoseWithCovarianceStamped, timeout = timeout)
    else:
        robot_pose = rospy.wait_for_message('/base_pose_ground_truth', Odometry, timeout = timeout)
    
    robot_pose_stamped = PoseStamped()
    robot_pose_stamped.header = robot_pose.header
    robot_pose_stamped.pose = robot_pose.pose.pose
    result = toUnicyclePose(robot_pose_stamped)
    return result


def getActorsPoses(timeout = 1.0) -> list:
    result = []
    actor1_pose = rospy.wait_for_message('/actor1_pose', PoseStamped, timeout = timeout/2.0)
    actor2_pose = rospy.wait_for_message('/actor2_pose', PoseStamped, timeout = timeout/2.0)
    result.append(toUnicyclePose(actor1_pose))
    result.append(toUnicyclePose(actor2_pose))
    return result






if __name__ == "__main__":

    rospy.init_node('main')

    start = UnicyclePose(x = 0.0, y = 0.0, theta = 0.0)
    end = UnicyclePose(x = 10.0, y = 10.0, theta = 0.0)
    plan = getPlan(start = start, end = end)

    print(len(plan))

    for i in range(0,len(plan),100):
        print(plan[i])


    # start_time = rospy.get_rostime()
    # rate = rospy.Rate(5)
    # i = 0
    # while (rospy.get_rostime() - start_time) < rospy.rostime.Duration(20):
    #     i = i + 1
    #     print(f"Sample {i}")
    #     print("Robot's Pose:", getRobotPose())
    #     actors_pose = getActorsPoses()
    #     print("Actor1's Pose:", actors_pose[0])
    #     print("Actor2's Pose:", actors_pose[1])
    #     rate.sleep()

    setRobotVelocity(0.1, 0.1, 0.1, duration = rospy.rostime.Duration(10), frequency = 10)


    rospy.on_shutdown(cleanUp)